﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quiz1_BMI_calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            double num1, num2, num3, result;
            num1 = Double.Parse(txtFeet.Text);
            num2 = Double.Parse(txtInch.Text);
            num3 = Double.Parse(txtLbs.Text);
            num1 = (num1 * 12) +num2;
            num1 = num1 * num1;
            num3 = num3 * 705;
            result = num3 / num1;
            result = Math.Round(result, 1);
            txtBMI.Text = Convert.ToString(result);
        }
    }
}
